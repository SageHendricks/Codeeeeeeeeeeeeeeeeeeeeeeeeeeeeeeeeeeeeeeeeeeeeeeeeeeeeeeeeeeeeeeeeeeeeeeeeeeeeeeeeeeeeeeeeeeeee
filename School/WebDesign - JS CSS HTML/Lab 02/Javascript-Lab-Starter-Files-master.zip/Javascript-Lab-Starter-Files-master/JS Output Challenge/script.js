// Enter your code below to edit index.html

yourName = "Ninjafiveo"
document.getElementById("yourName").innerHTML = yourName;